/* Actor declaration
*/

#include "actor.hpp"


Actor::Actor(const string& given_name)
{
	name = given_name;
}

/*Actor::~Actor()
{
	//nonexistent because Base Destructor takes care of everything
}*/