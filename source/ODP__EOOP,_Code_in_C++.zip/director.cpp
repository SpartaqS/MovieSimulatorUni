/* Director declaration
*/

#include "director.hpp"

Director::Director(const string& given_name)
{
	name = given_name;
}

/*Director::~Director()
{
	//nonexistent because Base Destructor takes care of everything
}*/